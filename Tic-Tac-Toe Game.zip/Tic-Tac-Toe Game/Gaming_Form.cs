﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe_Game
{
    public partial class Gaming_Form : Form
    {
        public Gaming_Form()
        {
            InitializeComponent();
            labelPlayer.Text = Player1;
            label3.Text = Player1;
            label4.Text = Player2;
        }

        string Player1 = TicTacToe_Form.Player1;
        string Player2 = TicTacToe_Form.Player2;


        void ClickAllButton(Button button)
        {
            if (button.Tag == null)
            {
                if (labelPlayer.Text == Player1)
                {
                    button.Text = "X";
                    button.Tag = "x";
                    button.Enabled = false;
                    labelPlayer.Text = Player2;
                    ChackWinner();
                }
                else if (labelPlayer.Text == Player2)
                {
                    button.Text = "O";
                    button.Tag = "o";
                    button.Enabled = false;
                    labelPlayer.Text = Player1;
                    ChackWinner();
                    
                }

            }
            
        }

         bool ChackValues(Button bt1, Button bt2, Button bt3)
        {
            if (bt1.Tag != null && bt2.Tag != null && bt3.Tag != null
                && bt1.Tag.ToString() == bt2.Tag.ToString()
                && bt1.Tag.ToString() == bt3.Tag.ToString())
            {
                bt1.BackColor = Color.Yellow;
                bt2.BackColor = Color.Yellow;
                bt3.BackColor = Color.Yellow;

                labelWinning.Text = (bt1.Text == "X") ? Player1 : Player2;
                labelPlayer.Text = " Game Over!!";
                groupBox1.Enabled = false;

                
                
                return true;

            }
            else
                return false;
            
        }

        void ChackWinner()
        {
            if (ChackValues(button3, button4, button5))
                return;

            if (ChackValues(button8, button7, button6))
                return;

            if (ChackValues(button11, button10, button9))
                return;



            if (ChackValues(button3, button8, button11))
                return;

            if (ChackValues(button4, button7, button10))
                return;

            if (ChackValues(button5, button6, button9))
                return;



            if (ChackValues(button3, button7, button9))
                return;

            if (ChackValues(button5, button7, button11))
                return;

          

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ClickAllButton(button3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ClickAllButton(button4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ClickAllButton(button5);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ClickAllButton(button8);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ClickAllButton(button7);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ClickAllButton(button6);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            ClickAllButton(button11);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            ClickAllButton(button10);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ClickAllButton(button9);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        void RestartGame(Button bt)
        {
            bt.Text = null;
            bt.Tag = null;
            bt.Enabled = true;
            bt.BackColor = Color.Navy;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button[] ArrButton = { button3, button4, button5, button6, button7,
                button8, button9, button10, button11};

            foreach (Button btn in ArrButton)
            {
                RestartGame(btn);
            }

            groupBox1.Enabled = true;
            labelPlayer.Text = Player1;
            labelWinning.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to Close ?", "to be sure",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                this.Close();
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }


}
