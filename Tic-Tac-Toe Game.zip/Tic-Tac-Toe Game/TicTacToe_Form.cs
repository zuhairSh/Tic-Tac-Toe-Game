﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe_Game
{
    public partial class TicTacToe_Form : Form
    {
        public TicTacToe_Form()
        {
            InitializeComponent();

        }

        public static string Player1;
        public static string Player2;

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you ready to play?", "to be sure",
                MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form MyForm = new Gaming_Form();
                MyForm.ShowDialog();
                this.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to Close ?", "to be sure",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                
                this.Close();
            }
        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {
            Player2 = textBox1.Text;

        }

        public void textBox2_TextChanged(object sender, EventArgs e)
        {
            Player1 = textBox2.Text;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
